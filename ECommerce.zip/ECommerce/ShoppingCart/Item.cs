using Catalog;
namespace ShoppingCart{

    public class Item{
        public Product theProduct{get; set;}
        public int Quantity{get; set;}
    }
}