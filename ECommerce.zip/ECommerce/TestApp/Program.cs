﻿using Catalog;
using CRM;
using Membership;
using OrderProcessing;
using ShoppingCart;

//Property Initilizer
Product p1 = new Product{
    Id=2,
    Title="Gerbera",
    Description="Wedding Flower",
    UnitPrice=10,
    Quantity=56000
};

Console.WriteLine(p1.Id+" "+p1.Title+" "+p1.Description);
